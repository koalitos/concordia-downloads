const { app, BrowserWindow, Tray, Menu, session, desktopCapturer, shell, ipcMain, nativeImage, utilityProcess } = require('electron')
const path = require('node:path')
const { createDisplayCaptureHandler } = require('./capture')
const { createSystemAudio } = require('./system-audio')
const { createNativeAudio } = require('./native-audio')
const { linuxAudioSources, linuxWindowPid, belongsToProcess, audioBlockReason } = require('./audio-sources')
const { createBundledRenderer } = require('./renderer')
const { configurar: configurarAtualizador } = require('./atualizador')

// Aponta pro site publicado. Dá pra rodar contra o servidor local com
// CONCORDIA_URL=http://localhost:3001 npm start — útil pra testar uma
// mudança do cliente dentro do app antes de publicar.
const APP_URL = process.env.CONCORDIA_URL || 'https://concordia.app.br'
const APP_ORIGIN = new URL(APP_URL).origin

// ASCII de propósito, e isso não é preciosismo: este nome entra no
// User-Agent e no caminho da pasta de dados. Cabeçalho HTTP é Latin-1, então
// um "ó" viaja como o byte 0xF3, que não é UTF-8 válido; o Supabase grava o
// user agent junto da sessão, o Postgres recusa o byte e o login volta como
// "Database error granting user" (HTTP 500) — só no app, nunca no navegador.
// O acento fica onde é só texto: título da janela e CFBundleDisplayName.
app.setName('Concordia')

const waylandSession = process.platform === 'linux' && Boolean(process.env.WAYLAND_DISPLAY || process.env.XDG_SESSION_TYPE === 'wayland')
if (waylandSession) {
  const enabled = app.commandLine.getSwitchValue('enable-features')
  app.commandLine.appendSwitch('enable-features', [enabled, 'WebRTCPipeWireCapturer'].filter(Boolean).join(','))
}

// Cinto e suspensório: se algo mais injetar caractere fora do ASCII no
// User-Agent, some aqui antes de virar requisição.
app.userAgentFallback = app.userAgentFallback.replace(/[^\x20-\x7E]/g, '')

let captureSourceType = 'screen'
let captureChoice = null
let captureSelection = null
let mainWindow = null
let tray = null
let atualizador = null
// Fechar a janela esconde em vez de encerrar; só sai de verdade por "Sair"
// na bandeja, pelo Cmd+Q ou por um update. Sem esta trava o app morreria no
// primeiro clique no X e a bandeja não serviria pra nada.
let saindoDeVerdade = false
let jaAvisouDaBandeja = false

const audioOptions = {
  send: (channel, data) => {
    if (mainWindow && !mainWindow.isDestroyed() && isOurOrigin(mainWindow.webContents.getURL())) mainWindow.webContents.send(channel, data)
  },
}
const systemAudio = process.platform === 'linux'
  ? createSystemAudio(audioOptions)
  : createNativeAudio({ ...audioOptions, fork: (...args) => utilityProcess.fork(...args) })
for (const [channel, handler] of [['system-audio:start', () => {
  return systemAudio.start()
}], ['system-audio:stop', () => systemAudio.stop()]]) {
  ipcMain.handle(channel, (event) => {
    if (event.sender !== mainWindow?.webContents || event.senderFrame !== event.sender.mainFrame || !isOurOrigin(event.senderFrame.url)) throw new Error('Origem inválida')
    return handler()
  })
}
app.on('before-quit', () => systemAudio.stop())

function isOurOrigin(url) {
  try {
    return new URL(url).origin === APP_ORIGIN
  } catch {
    return false
  }
}

// ---- seletor de tela ----------------------------------------------------
//
// No navegador quem desenha a lista de janelas é o próprio Chrome. No
// Electron esse seletor não existe: getDisplayMedia cai num handler que a
// gente tem que responder, e sem responder a chamada fica pendurada pra
// sempre — é por isso que um wrapper "só carrega o site" não transmite tela.
// Aqui a lista é montada com desktopCapturer e mostrada numa janelinha
// própria.
async function pickSource(parent, sources, preferredType, portal = false) {
  let audioSources = []
  let audioIssue = null
  try {
    audioSources = process.platform === 'linux' ? await linuxAudioSources() : await systemAudio.listSources(sources)
    for (const audio of audioSources) audio.sourceIds = audio.sourceId ? [audio.sourceId] : []
    if (process.platform === 'linux' && !portal) {
      for (const source of sources.filter((item) => item.id.startsWith('window:'))) {
        const pid = await linuxWindowPid(source.id)
        if (!pid) continue
        for (const audio of audioSources) {
          if (await belongsToProcess(audio.pid, pid)) audio.sourceIds.push(source.id)
        }
      }
    }
  } catch (error) {
    audioIssue = process.platform === 'linux'
      ? 'Para som isolado no Linux, instale libpulse (Arch) ou pulseaudio-utils (Ubuntu, Debian, Fedora e openSUSE).'
      : 'O áudio isolado não está disponível neste sistema. A imagem pode ser transmitida sem som.'
    console.warn('[audio] lista de aplicativos indisponível:', error.message)
  }
  return new Promise((resolve) => {
    const picker = new BrowserWindow({
      parent,
      modal: true,
      width: 760,
      height: portal ? 430 : 740,
      resizable: true,
      minimizable: false,
      maximizable: false,
      title: 'Escolha o que transmitir',
      backgroundColor: '#111113',
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true },
    })

    let answered = false
    const finish = (choice) => {
      if (answered) return
      answered = true
      ipcMain.removeHandler('picker:sources')
      ipcMain.removeListener('picker:choose', onChoose)
      if (!picker.isDestroyed()) picker.destroy()
      const source = sources.find((source) => source.id === choice?.sourceId)
      const candidate = audioSources.find((audio) => audio.id === choice?.audioId)
      const window = source?.id.startsWith('window:') || (portal && preferredType === 'window')
      const sourceBlocked = audioBlockReason(source?.name)
      const permitted = candidate && !candidate.blocked && !sourceBlocked && (portal || !window || candidate.sourceIds.includes(source.id))
      captureChoice = source ? { source, audio: permitted ? candidate : null, name: String(choice?.name || source.name).slice(0, 180), reason: sourceBlocked || (candidate?.blocked ? candidate.reason : audioIssue) } : null
      if (!source) systemAudio.stop()
      resolve(source || null)
    }

    ipcMain.handle('picker:sources', (event) => {
      if (event.sender !== picker.webContents) return []
      return { preferredType, portal, audioIssue, audioSources: audioSources.map(({ id, name, blocked, reason, sourceIds }) => ({ id, name, blocked, reason, sourceIds })), sources: sources.map((s) => ({
        id: s.id,
        name: s.name,
        isScreen: s.id.startsWith('screen:'),
        thumbnail: s.thumbnail.toDataURL(),
      })) }
    })

    const onChoose = (event, choice) => {
      if (event.sender === picker.webContents) finish(choice)
    }
    ipcMain.on('picker:choose', onChoose)
    // Fechar a janela no X é cancelar — resolve com null.
    picker.on('closed', () => finish(null))
    picker.loadFile(path.join(__dirname, 'picker.html'))
  })
}

ipcMain.handle('capture:prepare', (event, sourceType) => {
  if (event.sender !== mainWindow?.webContents || event.senderFrame !== event.sender.mainFrame || !isOurOrigin(event.senderFrame.url)) throw new Error('Origem inválida')
  if (!['screen', 'window'].includes(sourceType)) throw new Error('Tipo de captura inválido')
  captureSourceType = sourceType
  systemAudio.stop()
  captureChoice = null
  captureSelection = null
  return { isolatedAudio: true }
})
ipcMain.handle('capture:selection', (event) => {
  if (event.sender !== mainWindow?.webContents || event.senderFrame !== event.sender.mainFrame || !isOurOrigin(event.senderFrame.url)) throw new Error('Origem inválida')
  return captureSelection
})

function wireSession(ses) {
  // Use Chromium's direct network path by default, as in the working web app.
  // The bundled renderer remains available for explicit offline UI diagnostics.
  if (app.isPackaged && process.env.CONCORDIA_BUNDLED_CLIENT === '1' && !process.env.CONCORDIA_URL) {
    ses.protocol.handle('https', createBundledRenderer({
      origin: APP_ORIGIN,
      directory: path.join(process.resourcesPath, 'renderer'),
      fetchNetwork: (request) => ses.fetch(request, { bypassCustomProtocolHandlers: true }),
    }))
  }
  // O site é conhecido: concede câmera/tela sem pedir de novo (o sistema
  // operacional ainda pede a permissão dele, que é a que importa).
  // 'fullscreen' precisa estar aqui: sem ele o requestFullscreen do site
  // falha com "Permissions check failed" — só dentro do app, porque no
  // navegador não existe esse handler.
  const ALLOWED = new Set(['media', 'display-capture', 'notifications', 'clipboard-sanitized-write', 'fullscreen'])
  ses.setPermissionRequestHandler((contents, permission, callback, details) => {
    const wantsAudio = permission === 'media' && details?.mediaTypes?.includes('audio')
    callback(!wantsAudio && ALLOWED.has(permission) && isOurOrigin(contents.getURL()))
  })
  ses.setPermissionCheckHandler((contents, permission, _origin, details) => {
    if (permission === 'media' && details?.mediaType === 'audio') return false
    return ALLOWED.has(permission) && isOurOrigin(contents?.getURL() || '')
  })

  ses.setDisplayMediaRequestHandler(
    createDisplayCaptureHandler({
      getSources: (options) => desktopCapturer.getSources(options),
      pickSource: (sources) => pickSource(mainWindow, sources, captureSourceType),
      usePortal: waylandSession,
      onSelected: async (source, sources) => {
        if (waylandSession && !await pickSource(mainWindow, sources, captureSourceType, true)) return false
        const choice = captureChoice
        if (!choice || choice.source !== source) return false
        systemAudio.allow(choice.audio)
        captureSelection = {
          name: choice.name,
          kind: waylandSession ? 'portal' : source.id.startsWith('window:') ? 'window' : 'screen',
          audioName: choice.audio?.name || null,
          audioSelected: Boolean(choice.audio),
          audioReason: choice.reason || (choice.audio ? null : 'Nenhum áudio de aplicativo foi selecionado.'),
        }
      },
      // O seletor precisa das duas categorias. PipeWire abre uma única sessão
      // de portal para telas/janelas; filtrar antes escondia fontes em alguns SOs.
      sourceTypes: () => ['screen', 'window'],
      isTrusted: isOurOrigin,
    }),
    { useSystemPicker: false },
  )
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 380,
    minHeight: 520,
    backgroundColor: '#111113',
    title: 'Concórdia',
    icon: path.join(__dirname, 'build', 'icon.png'), // Windows/Linux usam este
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      // Vídeos mudos continuam com autoplay; áudio nunca deve iniciar sozinho.
      autoplayPolicy: 'user-gesture-required',
    },
  })

  // The page owns its theme. Injecting packaged CSS here made the desktop
  // override newer web styles and keep an old blue background indefinitely.
  mainWindow.loadURL(APP_URL)

  // Link externo abre no navegador do sistema, não dentro do app.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!isOurOrigin(url)) shell.openExternal(url)
    return { action: 'deny' }
  })
  mainWindow.webContents.on('will-navigate', (e, url) => {
    systemAudio.stop()
    if (!isOurOrigin(url)) {
      e.preventDefault()
      shell.openExternal(url)
    }
  })

  // Fechar vai pra bandeja. Numa call isso é o que a pessoa espera: some da
  // tela e a transmissão continua. Encerrar de verdade derrubaria a sala sem
  // aviso.
  mainWindow.on('close', (e) => {
    if (saindoDeVerdade) return
    e.preventDefault()
    mainWindow.hide()
    if (process.platform === 'darwin') app.dock?.hide()
    avisarQueFoiPraBandeja()
  })

  mainWindow.webContents.on('render-process-gone', () => systemAudio.stop())
  mainWindow.webContents.on('did-start-navigation', (_event, _url, _inPlace, isMainFrame) => { if (isMainFrame) systemAudio.stop() })
  mainWindow.on('closed', () => { systemAudio.stop(); mainWindow = null })
}

function mostrarJanela() {
  if (!mainWindow) {
    createWindow()
    return
  }
  if (process.platform === 'darwin') app.dock?.show()
  if (mainWindow.isMinimized()) mainWindow.restore()
  mainWindow.show()
  mainWindow.focus()
}

// A primeira vez que a janela some pra bandeja precisa de aviso: sem isso a
// pessoa acha que fechou o app, abre de novo e esbarra na trava de instância
// única — parece que o app não abre mais.
function avisarQueFoiPraBandeja() {
  if (jaAvisouDaBandeja || !tray) return
  jaAvisouDaBandeja = true
  if (process.platform === 'win32') {
    tray.displayBalloon({
      title: 'Concórdia continua aberto',
      content: 'A janela fechou, mas o app segue rodando aqui na bandeja. Para sair de vez, clique com o botão direito e escolha Sair.',
    })
  }
}

function criarBandeja() {
  // No macOS o ícone tem que ser template (preto com alfa) pra o sistema
  // inverter conforme a barra clara/escura. Nas outras plataformas não
  // existe template, e a barra costuma ser escura, então vai o branco.
  const arquivo = process.platform === 'darwin' ? 'trayTemplate.png' : 'tray.png'
  const caminho = path.join(__dirname, 'build', arquivo)
  const imagem = nativeImage.createFromPath(caminho)
  // createFromPath não lança quando o arquivo não existe: devolve imagem
  // vazia, e a bandeja aparece como um espaço em branco na barra. Deixar
  // isso passar calado é como o app ficou sem o atualizador.js.
  if (imagem.isEmpty()) console.error('[bandeja] ícone não carregou:', caminho)
  if (process.platform === 'darwin') imagem.setTemplateImage(true)

  tray = new Tray(imagem)
  tray.setToolTip('Concórdia')
  atualizarMenuBandeja()
  // No Windows e no Linux, clique simples alterna a janela.
  tray.on('click', () => {
    if (process.platform === 'darwin') return
    if (mainWindow?.isVisible()) mainWindow.hide()
    else mostrarJanela()
  })
}

function rotuloAtualizacao() {
  const estado = atualizador?.estado()
  switch (estado?.status) {
    case 'checking': return 'Verificando atualizações…'
    case 'downloading': return `Baixando atualização… ${estado.percent}%`
    case 'downloaded': return `Reiniciar e atualizar para ${estado.version}`
    case 'available': return `Baixar versão ${estado.version}`
    case 'current': return 'Você está na versão mais recente · Verificar novamente'
    case 'error': return 'Falha ao atualizar · Tentar novamente'
    case 'disabled': return 'Atualizações indisponíveis neste modo'
    default: return 'Verificar atualizações'
  }
}

function atualizarMenuBandeja() {
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: 'Abrir Concórdia', click: mostrarJanela },
      { label: `Versão ${app.getVersion()}`, enabled: false },
      {
        label: rotuloAtualizacao(),
        enabled: atualizador?.estado().status !== 'disabled',
        click: async () => {
          mostrarJanela()
          try {
            if (['downloaded', 'available'].includes(atualizador?.estado().status)) await atualizador.instalar()
            else await atualizador?.verificar()
          } catch (error) { console.error('[atualizador]', error) }
        },
      },
      { type: 'separator' },
      {
        label: 'Sair',
        click: () => {
          saindoDeVerdade = true
          app.quit()
        },
      },
    ]),
  )
}

// Uma instância só: abrir de novo traz a janela existente pra frente, em vez
// de subir um segundo app (que entraria na call e derrubaria o primeiro).
if (!app.requestSingleInstanceLock()) {
  app.quit()
} else {
  // Abrir de novo enquanto está na bandeja tem que TRAZER a janela de volta.
  // Sem o show(), a segunda abertura não fazia nada visível e o app parecia
  // travado.
  app.on('second-instance', mostrarJanela)

  app.whenReady().then(async () => {
    // Em desenvolvimento o dock usa o ícone do binário do Electron; isto
    // troca pelo barquinho. No app empacotado o ícone já vem do bundle.
    if (process.platform === 'darwin' && app.dock) {
      const icone = path.join(__dirname, 'build', 'icon.png')
      if (require('node:fs').existsSync(icone)) app.dock.setIcon(icone)
    }

    wireSession(session.defaultSession)
    criarBandeja()
    createWindow()
    atualizador = configurarAtualizador(app, {
      getWindow: () => mainWindow,
      isTrusted: isOurOrigin,
      ipcMain,
      mostrarJanela,
    })
    atualizador.observar(atualizarMenuBandeja)
    atualizarMenuBandeja()

    // Clicar no ícone do dock com a janela escondida tem que trazê-la de
    // volta, não abrir uma segunda.
    app.on('activate', mostrarJanela)
  })

  // Com bandeja, fechar a última janela NÃO encerra o app em nenhuma
  // plataforma — é o ponto de ficar na bandeja.
  app.on('window-all-closed', () => {})

  require('electron').autoUpdater.on('before-quit-for-update', () => { saindoDeVerdade = true })
  app.on('before-quit', () => { saindoDeVerdade = true })
}
