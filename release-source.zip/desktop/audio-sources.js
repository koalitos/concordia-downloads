const { execFile } = require('node:child_process')
const { promisify } = require('node:util')
const { readFile, readlink } = require('node:fs/promises')
const run = promisify(execFile)

function audioBlockReason(...names) {
  const text = names.filter(Boolean).join(' ')
  if (/discord|concordia|teamspeak|mumble|skype|zoom|webex|slack|telegram|whatsapp|signal|microsoft.?teams|ms-teams|\bteams(?:\.exe)?\b|google.?meet|element-desktop/i.test(text)) return 'Áudio de chamadas bloqueado para evitar retorno.'
  if (/firefox|chromium|chrome|brave|vivaldi|microsoft.?edge|msedge|opera|safari|zen-browser/i.test(text)) return 'Para separar o áudio de uma aba, compartilhe essa aba usando o Concórdia no navegador.'
  return null
}

async function belongsToProcess(pid, parent, read = readFile) {
  for (let i = 0; i < 64 && pid > 1; i++) {
    if (pid === parent) return true
    try {
      const stat = await read(`/proc/${pid}/stat`, 'utf8')
      const next = Number(stat.slice(stat.lastIndexOf(')') + 1).trim().split(/\s+/)[1])
      if (!next || next === pid) break
      pid = next
    } catch { break }
  }
  return false
}

async function linuxAudioSources({ execute = run } = {}) {
  const options = { encoding: 'utf8', timeout: 3000, maxBuffer: 2 * 1024 * 1024 }
  const [inputs, outputs, clients] = await Promise.all([
    execute('pactl', ['-f', 'json', 'list', 'sink-inputs'], options),
    execute('pactl', ['-f', 'json', 'list', 'sinks'], options),
    execute('pactl', ['-f', 'json', 'list', 'clients'], options),
  ])
  const sinks = JSON.parse(outputs.stdout)
  const clientList = JSON.parse(clients.stdout)
  const result = []
  for (const input of JSON.parse(inputs.stdout)) {
    const client = clientList.find((item) => item.index === Number(input.client))
    const properties = { ...client?.properties, ...input.properties }
    const pid = Number(properties['application.process.id'])
    const sink = sinks.find((item) => item.index === input.sink)
    const monitor = sink?.monitor_source_name || (typeof sink?.monitor_source === 'string' ? sink.monitor_source : null)
    if (!Number.isSafeInteger(input.index) || !Number.isSafeInteger(pid) || pid <= 1 || !monitor) continue
    const appName = properties['application.name'] || properties['application.process.binary'] || 'Aplicativo'
    const mediaName = properties['media.name'] || ''
    let executable = properties['application.process.binary'] || ''
    try { executable += ` ${await readlink(`/proc/${pid}/exe`)}` } catch { /* processo pode ter encerrado */ }
    const reason = audioBlockReason(appName, mediaName, executable)
    result.push({ id: `pulse:${input.index}`, index: input.index, pid, monitor,
      appName, name: mediaName && mediaName !== appName ? `${appName} · ${mediaName}` : appName,
      executable, blocked: Boolean(reason), reason })
  }
  return result
}

async function linuxWindowPid(sourceId, execute = run) {
  const handle = /^window:(\d+):/.exec(sourceId)?.[1]
  if (!handle || handle === '0') return null
  try {
    const { stdout } = await execute('xprop', ['-id', handle, '_NET_WM_PID'], { encoding: 'utf8', timeout: 2000 })
    const pid = Number(/=\s*(\d+)/.exec(stdout)?.[1])
    return Number.isSafeInteger(pid) && pid > 1 ? pid : null
  } catch { return null }
}

module.exports = { audioBlockReason, belongsToProcess, linuxAudioSources, linuxWindowPid }
