const path = require('node:path')
const native = require(path.join(__dirname, 'native-audio', 'prebuilt', `${process.platform}-${process.arch}`, 'concordia_audio.node'))
process.parentPort.on('message', ({ data }) => {
  try {
    if (data.type === 'inspect') {
      process.parentPort.postMessage({ id: data.id, result: data.sources.map((source) => ({ ...source, ...native.resolveWindow(source.handle) })) })
    } else if (data.type === 'start') {
      native.startCapture(data.pid, (bytes) => process.parentPort.postMessage({ type: 'pcm', bytes }))
      process.parentPort.postMessage({ id: data.id, result: true })
      setInterval(() => { if (!native.isCapturing()) { process.parentPort.postMessage({ type: 'error' }); process.exit(0) } }, 1000)
    } else if (data.type === 'stop') { native.stopCapture(); process.exit(0) }
  } catch { process.parentPort.postMessage({ id: data.id, error: 'O sistema não disponibilizou áudio isolado para este aplicativo.' }) }
})
