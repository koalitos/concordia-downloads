const { build, Platform, Arch } = require('electron-builder')
const { execFileSync } = require('node:child_process')
const path = require('node:path')

async function main() {
  execFileSync(process.execPath, [path.join(__dirname, 'build-native.cjs')], { stdio: 'inherit' })
  const mac = process.platform === 'darwin'
  const signed = mac && ['CSC_LINK', 'CSC_KEY_PASSWORD', 'APPLE_ID', 'APPLE_APP_SPECIFIC_PASSWORD', 'APPLE_TEAM_ID'].every((key) => Boolean(process.env[key]))
  if (mac && !signed) process.env.CSC_IDENTITY_AUTO_DISCOVERY = 'false'
  const platform = mac ? Platform.MAC : process.platform === 'win32' ? Platform.WINDOWS : Platform.LINUX
  const targets = mac
    ? platform.createTarget(['dmg', 'zip'], Arch.arm64, Arch.x64)
    : platform.createTarget(process.platform === 'win32' ? ['nsis'] : ['AppImage', 'tar.gz'], Arch.x64)
  await build({
    targets,
    publish: 'never',
    config: {
      extraMetadata: { concordiaSignedMac: signed },
      ...(mac ? { mac: {
        identity: signed ? undefined : null,
        hardenedRuntime: signed,
        ...(signed ? { entitlements: 'build/entitlements.mac.plist', entitlementsInherit: 'build/entitlements.mac.plist' } : {}),
      } } : {}),
    },
  })
}
main().catch((error) => { console.error(error); process.exitCode = 1 })
