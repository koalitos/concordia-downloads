const { execFileSync } = require('node:child_process')
const fs = require('node:fs')
const path = require('node:path')

// Sem certificado da Apple, o electron-builder pula a assinatura e o bundle
// sai com a assinatura que o linker deixou só no binário principal: sem
// recursos selados, Info.plist não vinculado. No Apple Silicon isso é fatal
// — o macOS recusa abrir. Então assinamos ad-hoc aqui.
//
// De dentro pra fora, e sem --deep. O --deep passa no `codesign --verify`
// e mesmo assim o app morre com SIGTRAP (código 133) na abertura: ele
// reaproveita as mesmas opções em tudo que está aninhado e não respeita a
// ordem. Assinar um pai antes dos filhos invalida o pai.
//
// E COM as permissões de JIT. Assinar sem elas dá o mesmo SIGTRAP, mas por
// outro motivo: a pilha da falha cai dentro do V8, que precisa alocar
// memória executável. No Apple Silicon isso exige allow-jit mesmo em
// assinatura ad-hoc — foi o que sobrou depois de acertar a ordem.
//
// Isto não dá procedência nenhuma: o Gatekeeper continua dizendo que o
// desenvolvedor é desconhecido, e a pessoa ainda precisa abrir com o botão
// direito na primeira vez. O que muda é o app deixar de ser inválido.
// Nem todo binário tem extensão: o chrome_crashpad_handler, dentro do
// framework, não tem nenhuma — e um único Mach-O sem assinatura invalida o
// bundle inteiro. Então a decisão é pelo conteúdo, não pelo nome.
const MAGICOS = new Set([0xfeedface, 0xfeedfacf, 0xcafebabe, 0xbebafeca, 0xcffaedfe, 0xcefaedfe])

function ehMachO(arquivo) {
  let fd
  try {
    fd = fs.openSync(arquivo, 'r')
    const buf = Buffer.alloc(4)
    if (fs.readSync(fd, buf, 0, 4, 0) < 4) return false
    return MAGICOS.has(buf.readUInt32BE(0)) || MAGICOS.has(buf.readUInt32LE(0))
  } catch {
    return false
  } finally {
    if (fd !== undefined) fs.closeSync(fd)
  }
}

function coletarAninhados(dir, acc = []) {
  let entradas
  try {
    entradas = fs.readdirSync(dir, { withFileTypes: true })
  } catch {
    return acc
  }
  for (const e of entradas) {
    const p = path.join(dir, e.name)
    if (e.isSymbolicLink()) continue // Versions/Current e afins: assinar duas vezes quebra
    if (e.isDirectory()) {
      coletarAninhados(p, acc) // filhos primeiro — é o que garante a ordem
      if (/\.(app|framework)$/.test(e.name)) acc.push(p)
    } else if (ehMachO(p)) {
      acc.push(p)
    }
  }
  return acc
}

/**
 * Confere que todo require('./algo') do main.js existe dentro do asar.
 *
 * A lista "files" do package.json é uma allow-list: arquivo novo que não é
 * adicionado nela simplesmente não entra no pacote, e o build passa sem um
 * aviso sequer. O app só quebra na abertura, no computador de quem baixou,
 * com "Cannot find module". Foi exatamente o que aconteceu com o
 * atualizador.js.
 */
function conferirModulosLocais(context) {
  const recursos =
    context.electronPlatformName === 'darwin'
      ? path.join(context.appOutDir, `${context.packager.appInfo.productFilename}.app`, 'Contents', 'Resources')
      : path.join(context.appOutDir, 'resources')

  if (!fs.existsSync(path.join(recursos, 'renderer', 'index.html'))) {
    throw new Error('Cliente não compilado. Execute npm run build:renderer antes de empacotar o desktop.')
  }
  const asar = path.join(recursos, 'app.asar')
  if (!fs.existsSync(asar)) return

  // O @electron/asar já vem com o electron-builder. Lê a listagem sem
  // extrair nada pro disco.
  // asar returns native separators: normalize Windows paths before checking.
  const dentro = new Set(require('@electron/asar').listPackage(asar).map((nome) => nome.replace(/\\/g, '/')))

  // A fonte da verdade é o main.js do repositório: é ele que diz o que
  // precisa existir lá dentro.
  const main = fs.readFileSync(path.join(__dirname, 'main.js'), 'utf8')
  const faltando = []
  for (const m of main.matchAll(/require\((?:'|")(\.[^'"]+)(?:'|")\)/g)) {
    const alvo = m[1].replace(/^\.\//, '')
    const candidatos = [`/${alvo}`, `/${alvo}.js`, `/${alvo}/index.js`]
    if (!candidatos.some((c) => dentro.has(c))) faltando.push(m[1])
  }

  // Assets que o main.js carrega por caminho, não por require. Faltando um
  // desses nada explode: o nativeImage devolve imagem vazia e o ícone da
  // bandeja simplesmente não aparece — falha silenciosa, a pior de achar.
  const ASSETS = ['/build/trayTemplate.png', '/build/trayTemplate@2x.png', '/build/tray.png', '/build/icon.png', '/omarchy.css']
  for (const a of ASSETS) if (!dentro.has(a)) faltando.push(a)

  if (faltando.length) {
    throw new Error(
      `estes arquivos são exigidos pelo main.js e NÃO entraram no pacote: ${faltando.join(', ')}\n` +
        '  adicione o arquivo em build.files no desktop/package.json',
    )
  }
  console.log(`  • módulos e assets conferidos (${dentro.size} entradas no asar)`)
}

exports.default = async function afterPack(context) {
  conferirModulosLocais(context)
  if (context.electronPlatformName !== 'darwin') return

  // Com certificado de verdade (CSC_LINK/CSC_NAME), quem assina é o
  // electron-builder e re-assinar ad-hoc aqui DESTRUIRIA essa assinatura —
  // o app voltaria a ser "de desenvolvedor não identificado" e a
  // atualização automática pararia de funcionar no macOS.
  if (process.env.CSC_LINK || process.env.CSC_NAME) {
    console.log('  • certificado presente: assinatura ad-hoc pulada')
    return
  }

  const app = path.join(context.appOutDir, `${context.packager.appInfo.productFilename}.app`)
  const permissoes = path.join(__dirname, 'build', 'entitlements.mac.plist')
  // Do mais fundo pro mais raso. A recursão sozinha não garante isso entre
  // irmãos: "Versions/A/Electron Framework" aparecia antes de
  // "Versions/A/Helpers/chrome_crashpad_handler", e assinar o pai antes do
  // filho deixava o pai inválido de novo.
  const profundidade = (p) => p.split(path.sep).length
  const alvos = [
    ...coletarAninhados(path.join(app, 'Contents')).sort((a, b) => profundidade(b) - profundidade(a)),
    app,
  ]

  for (const alvo of alvos) {
    try {
      execFileSync(
        'codesign',
        ['--force', '--timestamp=none', '--entitlements', permissoes, '--sign', '-', alvo],
        { stdio: 'pipe' },
      )
    } catch (err) {
      // Sem isto o erro do codesign some e sobra só "Command failed".
      const detalhe = (err.stderr || '').toString().trim() || err.message
      throw new Error(`codesign falhou em ${alvo}\n  ${detalhe}`)
    }
  }

  // Falhar aqui é melhor do que publicar um .dmg que não abre.
  execFileSync('codesign', ['--verify', '--deep', '--strict', app], { stdio: 'inherit' })
  console.log(`  • assinado ad-hoc (${alvos.length} alvos)  ${app}`)
}
