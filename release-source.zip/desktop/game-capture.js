// A title is not an application identity. Resolve window owners through the
// native helper and restrict a session to one known game installation.
function leagueWindow(target) {
  if (!target?.sourceId?.startsWith('window:') || target.blocked || !(target.pid > 1)) return null
  const executable = String(target.executable || '').replaceAll('\\', '/').toLowerCase()
  const name = executable.split('/').pop()
  const phase = /^leagueclientux(?:\.exe)?$/.test(name) ? 'launcher'
    : /^(?:league of legends(?:\.exe)?|leagueoflegends)$/.test(name) ? 'game' : null
  if (!phase || !executable.includes('/')) return null
  const macRoot = executable.indexOf('/contents/lol/')
  const root = macRoot >= 0 ? executable.slice(0, macRoot + '/contents/lol'.length)
    : executable.slice(0, executable.lastIndexOf('/')).replace(/\/game$/, '')
  return { profile: 'league', label: 'League of Legends / TFT', phase, root }
}

function createGameCapture({ getSources, inspect }) {
  let active = null
  let sequence = 0
  function stop(session) {
    if (!session || session === active?.session) active = null
  }
  function start(target) {
    stop()
    const identity = leagueWindow(target)
    if (!identity) return null
    active = { ...identity, session: String(++sequence), sourceId: target.sourceId, pid: target.pid }
    return { session: active.session, sourceId: target.sourceId, pid: target.pid, phase: identity.phase }
  }
  async function next(session) {
    const current = active
    if (!current || current.session !== session) return null
    const sources = await getSources({ types: ['window'], thumbnailSize: { width: 0, height: 0 }, fetchWindowIcons: false })
    const targets = await inspect(sources)
    if (active !== current) return null
    const candidates = targets.filter((target) => sources.some((source) => source.id === target.sourceId)
      && leagueWindow(target)?.root === current.root)
    const matches = candidates.filter((target) => leagueWindow(target).phase === 'game')
    const preferred = matches.length ? matches : candidates.filter((target) => leagueWindow(target).phase === 'launcher')
    const target = preferred.find((target) => target.sourceId === current.sourceId && target.pid === current.pid)
      || (preferred.length === 1 ? preferred[0] : null)
    if (!target) return { session, sourceId: null, phase: 'waiting' }
    return { session, sourceId: target.sourceId, pid: target.pid, phase: leagueWindow(target).phase }
  }
  async function validate(session, target) {
    const current = active
    if (!current || session !== current.session) return null
    const sources = await getSources({ types: ['window'], thumbnailSize: { width: 0, height: 0 }, fetchWindowIcons: false })
    const source = sources.find((source) => source.id === target?.sourceId)
    if (!source) return null
    const [owner] = await inspect([source])
    if (active !== current || owner?.pid !== target.pid || leagueWindow(owner)?.root !== current.root) return null
    current.sourceId = owner.sourceId
    current.pid = owner.pid
    return owner
  }
  return { start, next, validate, stop, isActive: () => Boolean(active), hasSession: (session) => Boolean(active && active.session === session) }
}

module.exports = { leagueWindow, createGameCapture }
