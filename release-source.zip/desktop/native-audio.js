const path = require('node:path')
const { audioBlockReason } = require('./audio-sources')

function createNativeAudio({ fork, send, timeoutMs = 10000 }) {
  let worker = null, allowed = null, sequence = 0
  const pending = new Map()
  function stop() {
    allowed = null
    const previous = worker; worker = null
    for (const { reject, timer } of pending.values()) { clearTimeout(timer); reject(new Error('Captura de som encerrada.')) }
    pending.clear()
    previous?.kill()
  }
  function ensureWorker() {
    if (worker) return worker
    const next = fork(path.join(__dirname, 'audio-worker.js'), [], { serviceName: 'Concordia Application Audio' })
    worker = next
    next.on('message', (message) => {
      if (worker !== next) return
      if (message.type === 'pcm') { send('system-audio:data', message.bytes); return }
      if (message.type === 'error') { send('system-audio:error', 'O som do aplicativo foi encerrado.'); stop(); return }
      const item = pending.get(message.id)
      if (!item) return
      clearTimeout(item.timer); pending.delete(message.id)
      if (message.error) item.reject(new Error(message.error))
      else item.resolve(message.result)
    })
    next.on('exit', () => { if (worker === next) { send('system-audio:error', 'O som do aplicativo foi interrompido.'); stop() } })
    return next
  }
  function request(type, data) {
    return new Promise((resolve, reject) => {
      const next = ensureWorker(), id = ++sequence
      const timer = setTimeout(() => { pending.delete(id); reject(new Error('O sistema não respondeu à captura de áudio isolado.')); stop() }, timeoutMs)
      pending.set(id, { resolve, reject, timer })
      next.postMessage({ type, id, ...data })
    })
  }
  async function listSources(sources) {
    const windows = sources.filter((source) => /^window:\d+:/.test(source.id)).map((source) => ({ sourceId: source.id, handle: Number(source.id.split(':')[1]), name: source.name }))
    const result = await request('inspect', { sources: windows })
    return result.filter((item) => item.pid > 1 && item.executable).map((item) => {
      const reason = audioBlockReason(item.name, item.executable)
      return { ...item, id: `app:${item.sourceId}`, blocked: Boolean(reason), reason }
    })
  }
  return {
    listSources, stop,
    allow(target) { allowed = target && !target.blocked ? target : null },
    async start() {
      const target = allowed; allowed = null
      if (!target || target.blocked) throw new Error('Selecione uma janela para compartilhar o áudio isolado.')
      const [current] = await request('inspect', { sources: [{ handle: target.handle, name: target.name, sourceId: target.sourceId }] })
      if (!current || current.pid !== target.pid || current.executable !== target.executable || audioBlockReason(current.name, current.executable)) throw new Error('O aplicativo selecionado foi encerrado ou alterado.')
      await request('start', { pid: target.pid })
      return { sampleRate: 48000 }
    },
  }
}
module.exports = { createNativeAudio }
