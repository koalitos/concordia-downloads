// PipeWire presents its own portal picker. Its source belongs to that
// request: enumerating again can replace the session and invalidate it.
function createDisplayCaptureHandler({
  getSources,
  pickSource,
  usePortal,
  isTrusted,
  sourceTypes = () => ['screen', 'window'],
  onError = console.error,
}) {
  let selecting = false
  return async (request, callback) => {
    let answered = false
    const finish = (streams) => {
      if (answered) return
      answered = true
      callback(streams)
    }
    if (
      selecting ||
      !request.videoRequested ||
      !isTrusted(request.securityOrigin)
    ) {
      finish(null)
      return
    }
    selecting = true
    try {
      const sources = await getSources({
        types: sourceTypes(request),
        thumbnailSize: usePortal
          ? { width: 0, height: 0 }
          : { width: 320, height: 200 },
        fetchWindowIcons: false,
      })
      const source = usePortal ? sources[0] : await pickSource(sources)
      // Use the actual object returned by this enumeration, not an ID
      // looked up through another getSources() call. No audio is granted.
      finish(source && sources.includes(source) ? { video: source } : null)
    } catch (error) {
      onError('[capture]', error)
      if (!answered) finish(null)
    } finally {
      selecting = false
    }
  }
}

module.exports = { createDisplayCaptureHandler }
