const fs = require('node:fs/promises')
const path = require('node:path')

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.wasm': 'application/wasm',
  '.ico': 'image/x-icon',
}

// Serve the installed UI under its existing HTTPS origin. Auth storage stays
// at the same origin; API, Socket.io and Supabase requests still use the network.
function createBundledRenderer({ origin, directory, fetchNetwork }) {
  const root = path.resolve(directory)
  return async (request) => {
    const url = new URL(request.url)
    if (url.origin !== origin || !['GET', 'HEAD'].includes(request.method))
      return fetchNetwork(request)
    const isIndex = url.pathname === '/' || url.pathname === '/index.html'
    if (!isIndex && !url.pathname.startsWith('/assets/') && !url.pathname.startsWith('/brand/'))
      return fetchNetwork(request)
    let relative
    try {
      relative = isIndex
        ? 'index.html'
        : decodeURIComponent(url.pathname.slice(1))
    } catch {
      return new Response('Invalid path', { status: 400 })
    }
    const file = path.resolve(root, relative)
    if (!file.startsWith(root + path.sep))
      return new Response('Forbidden', { status: 403 })
    try {
      const body = await fs.readFile(file)
      return new Response(request.method === 'HEAD' ? null : body, {
        headers: {
          'content-type':
            MIME[path.extname(file)] || 'application/octet-stream',
          'cache-control': 'no-store',
          'x-concordia-client': 'bundled',
        },
      })
    } catch (error) {
      if (['ENOENT', 'EISDIR'].includes(error.code))
        return new Response('Not found', { status: 404 })
      throw error
    }
  }
}
module.exports = { createBundledRenderer }
