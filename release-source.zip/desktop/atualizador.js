const { autoUpdater } = require('electron-updater')
const { dialog, net, shell, Notification } = require('electron')
const semver = require('semver')
const { concordiaSignedMac } = require('./package.json')

const RELEASES = 'https://github.com/koalitos/concordia-downloads/releases/latest'
const RELEASE_API = 'https://api.github.com/repos/koalitos/concordia-downloads/releases/latest'
const INTERVALO = 15 * 60 * 1000

function podeAtualizar(app) {
  if (process.mas || process.windowsStore) return false
  if (process.platform === 'linux' && !process.env.APPIMAGE) return false
  if (process.platform === 'darwin') {
    return app.isPackaged && process.mas !== true && concordiaSignedMac === true
  }
  return app.isPackaged
}

function configurar(app, { getWindow, isTrusted, ipcMain, mostrarJanela }) {
  const automatico = podeAtualizar(app)
  const habilitado = app.isPackaged && !process.mas && !process.windowsStore
  let estado = {
    status: habilitado ? 'idle' : 'disabled',
    currentVersion: app.getVersion(),
    version: null,
    percent: 0,
    automatic: automatico,
  }
  let pendente = null
  let confirmando = false
  let notificado = null
  const ouvintes = new Set()

  function publicar(patch) {
    estado = { ...estado, ...patch }
    const janela = getWindow()
    if (janela && !janela.isDestroyed() && isTrusted(janela.webContents.getURL())) {
      janela.webContents.send('updater:state', estado)
    }
    for (const ouvir of ouvintes) ouvir(estado)
  }

  function falhar(error) {
    console.error('[atualizador]', error?.message || error)
    publicar({ status: 'error' })
  }

  function avisar() {
    if (notificado === estado.version || !Notification.isSupported()) return
    try {
      const aviso = new Notification({
        title: 'Atualização do Concórdia',
        body: estado.status === 'downloaded'
          ? `A versão ${estado.version} está pronta. Abra o app para reiniciar e atualizar.`
          : `A versão ${estado.version} está disponível. Abra o app para baixar.`,
      })
      aviso.on('click', mostrarJanela)
      aviso.show()
      notificado = estado.version
    } catch (error) {
      console.error('[atualizador] aviso do sistema:', error?.message || error)
    }
  }

  if (automatico) {
    autoUpdater.autoDownload = true
    autoUpdater.autoInstallOnAppQuit = true
    autoUpdater.allowPrerelease = false
    autoUpdater.allowDowngrade = false
    const on = (nome, callback) => autoUpdater.on(nome, callback)
    on('error', falhar)
    on('checking-for-update', () => publicar({ status: 'checking' }))
    on('update-not-available', () => publicar({ status: 'current', version: null, percent: 0 }))
    on('update-available', ({ version }) => publicar({ status: 'downloading', version, percent: 0 }))
    on('download-progress', ({ percent }) => publicar({ status: 'downloading', percent: Math.max(0, Math.min(100, Math.round(percent || 0))) }))
    on('update-downloaded', ({ version }) => {
      publicar({ status: 'downloaded', version, percent: 100 })
      avisar()
    })
  }

  async function consultar() {
    publicar({ status: 'checking' })
    try {
      if (automatico) {
        const resultado = await autoUpdater.checkForUpdates()
        // O download termina depois da consulta. A falha também precisa ser tratada.
        resultado?.downloadPromise?.catch(falhar)
      } else {
        const response = await net.fetch(RELEASE_API, {
          headers: { Accept: 'application/vnd.github+json' },
          signal: AbortSignal.timeout(30000),
        })
        if (response.status === 404) {
          publicar({ status: 'current', version: null })
          return
        }
        if (!response.ok) throw new Error(`GitHub: HTTP ${response.status}`)
        const release = await response.json()
        const version = semver.valid(release.tag_name)
        if (!version) throw new Error('Versão inválida no release do GitHub')
        const nova = !release.draft && !release.prerelease && !semver.prerelease(version) && semver.gt(version, app.getVersion())
        publicar({ status: nova ? 'available' : 'current', version: nova ? version : null })
        if (nova) avisar()
      }
    } catch (error) {
      falhar(error)
    }
  }

  function verificar() {
    if (!habilitado || ['downloading', 'downloaded', 'installing'].includes(estado.status)) return Promise.resolve(estado)
    if (!pendente) pendente = consultar().finally(() => { pendente = null })
    return pendente.then(() => estado)
  }

  async function instalar() {
    if (estado.status === 'available' && !automatico) {
      await shell.openExternal(RELEASES)
      return
    }
    if (estado.status !== 'downloaded' || confirmando) return
    confirmando = true
    try {
      const janela = getWindow()
      const options = {
        type: 'info',
        buttons: ['Reiniciar e atualizar', 'Depois'],
        defaultId: 1,
        cancelId: 1,
        title: 'Atualizar Concórdia',
        message: `Instalar a versão ${estado.version}?`,
        detail: 'Reiniciar encerra suas transmissões e desconecta da sala. Se escolher Depois, a atualização será instalada ao sair do aplicativo pelo menu da bandeja.',
      }
      const { response } = await (janela && !janela.isDestroyed()
        ? dialog.showMessageBox(janela, options)
        : dialog.showMessageBox(options))
      if (response === 0) {
        publicar({ status: 'installing' })
        autoUpdater.quitAndInstall(false, true)
      }
    } finally {
      confirmando = false
    }
  }

  const handlers = {
    'updater:get-state': () => estado,
    'updater:check': verificar,
    'updater:install': instalar,
  }
  for (const [canal, handler] of Object.entries(handlers)) {
    ipcMain.handle(canal, (event) => {
      if (event.sender !== getWindow()?.webContents || event.senderFrame !== event.sender.mainFrame || !isTrusted(event.senderFrame.url)) {
        throw new Error('Origem inválida')
      }
      return handler()
    })
  }
  const timer = habilitado ? setInterval(verificar, INTERVALO) : null
  timer?.unref()
  app.once('will-quit', () => {
    if (timer) clearInterval(timer)
    for (const canal of Object.keys(handlers)) ipcMain.removeHandler(canal)
    ouvintes.clear()
  })
  void verificar()
  return {
    verificar,
    instalar,
    estado: () => estado,
    observar(callback) { ouvintes.add(callback); return () => ouvintes.delete(callback) },
  }
}

module.exports = { configurar, podeAtualizar }
