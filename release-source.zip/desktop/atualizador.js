const { autoUpdater } = require('electron-updater')
const { dialog } = require('electron')
const { concordiaSignedMac } = require('./package.json')

// Atualização automática pelo GitHub Releases do repositório público de
// instaladores (o mesmo de onde as pessoas baixam).
//
// Requisito que não dá pra contornar: no macOS, o Squirrel só aceita
// atualizar um app ASSINADO com Developer ID. Sem certificado, o app abre
// normalmente mas NÃO se atualiza sozinho — e é melhor não checar do que
// prometer uma atualização que vai falhar calada. No Windows funciona sem
// assinatura, com o SmartScreen reclamando na instalação.
function podeAtualizar(app) {
  // Pacotes portáteis Linux não têm integração de auto-update.
  if (process.platform === 'linux' && !process.env.APPIMAGE) return false
  if (process.platform === 'darwin') {
    // isPackaged + assinatura válida. Em dev nunca atualiza.
    return app.isPackaged && process.mas !== true && concordiaSignedMac === true
  }
  return app.isPackaged
}

function configurar(app, janela) {
  if (!podeAtualizar(app)) {
    console.log('[atualizador] desligado (app não empacotado ou sem assinatura no macOS)')
    return
  }

  autoUpdater.autoDownload = true
  // Instalar sozinho ao fechar seria o ideal, mas numa call em andamento
  // reiniciar sem avisar é hostil. Pergunta primeiro.
  autoUpdater.autoInstallOnAppQuit = true

  autoUpdater.on('error', (err) => {
    console.error('[atualizador] erro:', err?.message || err)
  })

  autoUpdater.on('update-downloaded', async ({ version }) => {
    const { response } = await dialog.showMessageBox(janela, {
      type: 'info',
      buttons: ['Reiniciar agora', 'Depois'],
      defaultId: 0,
      cancelId: 1,
      title: 'Atualização pronta',
      message: `A versão ${version} do Concórdia está pronta.`,
      detail: 'Reiniciar leva alguns segundos. Se você estiver numa call, escolha "Depois" — a atualização é aplicada quando você fechar o app.',
    })
    if (response === 0) autoUpdater.quitAndInstall()
  })

  autoUpdater.checkForUpdates().catch(() => {})
  // Uma vez a cada 6h dá conta: o app costuma ficar aberto o dia todo.
  setInterval(() => autoUpdater.checkForUpdates().catch(() => {}), 6 * 60 * 60 * 1000).unref()
}

module.exports = { configurar, podeAtualizar }
