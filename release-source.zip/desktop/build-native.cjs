const { execFileSync } = require('node:child_process')
const fs = require('node:fs')
const path = require('node:path')
if (process.platform === 'linux') process.exit(0)
const root = path.join(__dirname, 'native-audio')
const gyp = require.resolve('node-gyp/bin/node-gyp.js')
for (const arch of process.platform === 'darwin' ? ['arm64', 'x64'] : ['x64']) {
  execFileSync(process.execPath, [gyp, 'rebuild', `--arch=${arch}`, '--directory', root], { stdio: 'inherit' })
  const destination = path.join(root, 'prebuilt', `${process.platform}-${arch}`)
  fs.mkdirSync(destination, { recursive: true })
  fs.copyFileSync(path.join(root, 'build/Release/concordia_audio.node'), path.join(destination, 'concordia_audio.node'))
}
