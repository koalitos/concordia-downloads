const { contextBridge, ipcRenderer } = require('electron')

// Ponte mínima e fechada: só o seletor de tela fala com o processo
// principal. O site em si não ganha nenhuma capacidade nova — ele roda
// exatamente como roda no navegador.
contextBridge.exposeInMainWorld('picker', {
  listar: () => ipcRenderer.invoke('picker:sources'),
  escolher: (id) => ipcRenderer.send('picker:choose', id),
})

contextBridge.exposeInMainWorld('concordiaDesktop', {
  versao: process.versions.electron,
  prepareCapture: (sourceType) => ipcRenderer.invoke('capture:prepare', sourceType),
})
