const { contextBridge, ipcRenderer } = require('electron')

// Ponte fechada: captura e atualização têm canais específicos, validados
// no processo principal. Não expõe IPC genérico nem URLs de download.
contextBridge.exposeInMainWorld('picker', {
  listar: () => ipcRenderer.invoke('picker:sources'),
  escolher: (choice) => ipcRenderer.send('picker:choose', choice),
})

contextBridge.exposeInMainWorld('concordiaDesktop', {
  versao: process.versions.electron,
  systemAudio: {
    supported: ['linux', 'win32', 'darwin'].includes(process.platform),
    isolated: true,
    start: () => ipcRenderer.invoke('system-audio:start'),
    stop: () => ipcRenderer.invoke('system-audio:stop'),
    onData: (callback) => {
      const listener = (_event, bytes) => callback(bytes)
      ipcRenderer.on('system-audio:data', listener)
      return () => ipcRenderer.removeListener('system-audio:data', listener)
    },
    onError: (callback) => {
      const listener = (_event, message) => callback(message)
      ipcRenderer.on('system-audio:error', listener)
      return () => ipcRenderer.removeListener('system-audio:error', listener)
    },
  },
  atualizacoes: {
    estado: () => ipcRenderer.invoke('updater:get-state'),
    verificar: () => ipcRenderer.invoke('updater:check'),
    instalar: () => ipcRenderer.invoke('updater:install'),
    observar: (callback) => {
      const listener = (_event, estado) => callback(estado)
      ipcRenderer.on('updater:state', listener)
      return () => ipcRenderer.removeListener('updater:state', listener)
    },
  },
  prepareCapture: (sourceType) => ipcRenderer.invoke('capture:prepare', sourceType),
  capture: { version: 2, selection: () => ipcRenderer.invoke('capture:selection') },
  gameCapture: {
    next: (session) => ipcRenderer.invoke('game-capture:next', session),
    audio: (session, target) => ipcRenderer.invoke('game-capture:audio', session, target),
    stop: (session) => ipcRenderer.invoke('game-capture:stop', session),
  },
})
