{
  "targets": [{
    "target_name": "concordia_audio",
    "include_dirs": ["<!@(node -p \"require('node-addon-api').include\")"],
    "dependencies": ["<!(node -p \"require('node-addon-api').gyp\")"],
    "defines": ["NAPI_DISABLE_CPP_EXCEPTIONS", "NAPI_VERSION=8"],
    "sources": ["addon.cc"],
    "conditions": [
      ["OS=='win'", {
        "sources": ["win/wasapi_capture.cpp"],
        "defines": ["_WIN32_WINNT=0x0A00", "NTDDI_VERSION=0x0A00000A"],
        "msvs_settings": {"VCCLCompilerTool": {"AdditionalOptions": ["/std:c++17"]}},
        "libraries": ["Mmdevapi.lib", "Avrt.lib", "Ole32.lib", "User32.lib"]
      }],
      ["OS=='mac'", {
        "sources": ["mac/coreaudio_capture.mm"],
        "xcode_settings": {"CLANG_ENABLE_OBJC_ARC": "YES", "OTHER_CPLUSPLUSFLAGS": ["-std=c++17"], "MACOSX_DEPLOYMENT_TARGET": "13.0"},
        "libraries": ["-framework CoreAudio", "-framework CoreMedia", "-framework CoreGraphics", "-framework ScreenCaptureKit", "-framework Foundation", "-framework AudioToolbox"]
      }]
    ]
  }]
}
