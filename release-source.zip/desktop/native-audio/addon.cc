#include <napi.h>
#include <vector>
#include <string>
#ifdef _WIN32
#include "win/wasapi_capture.h"
using Capture = WasapiCapture;
#else
#include "mac/coreaudio_capture.h"
#include <libproc.h>
using Capture = CoreAudioCapture;
#endif

static Capture capture;
static Napi::ThreadSafeFunction callback;
static bool started = false;

Napi::Value ResolveWindow(const Napi::CallbackInfo& info) {
  auto env = info.Env();
  if (info.Length() != 1 || !info[0].IsNumber()) return env.Null();
  uint64_t handle = (uint64_t)info[0].As<Napi::Number>().Int64Value();
  uint32_t pid = 0;
  std::string name;
#ifdef _WIN32
  HWND hwnd = (HWND)(uintptr_t)handle;
  GetWindowThreadProcessId(hwnd, (DWORD*)&pid);
  char className[256] = {};
  GetClassNameA(hwnd, className, sizeof(className));
  if (strcmp(className, "ApplicationFrameWindow") == 0) {
    EnumChildWindows(hwnd, [](HWND child, LPARAM param) -> BOOL {
      char name[256] = {};
      GetClassNameA(child, name, sizeof(name));
      if (strcmp(name, "Windows.UI.Core.CoreWindow") != 0) return TRUE;
      GetWindowThreadProcessId(child, (DWORD*)param);
      return FALSE;
    }, (LPARAM)&pid);
  }
  HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
  if (process) {
    wchar_t path[32768]; DWORD length = 32768;
    if (QueryFullProcessImageNameW(process, 0, path, &length)) {
      int bytes = WideCharToMultiByte(CP_UTF8, 0, path, length, nullptr, 0, nullptr, nullptr);
      name.resize(bytes);
      WideCharToMultiByte(CP_UTF8, 0, path, length, name.data(), bytes, nullptr, nullptr);
    }
    CloseHandle(process);
  }
#else
  pid = getPidFromWindowId((uint32_t)handle);
  char path[PROC_PIDPATHINFO_MAXSIZE] = {};
  if (pid && proc_pidpath(pid, path, sizeof(path)) > 0) name = path;
#endif
  auto result = Napi::Object::New(env);
  result.Set("pid", pid); result.Set("executable", name);
  return result;
}

Napi::Value Start(const Napi::CallbackInfo& info) {
  auto env = info.Env();
  if (started || info.Length() != 2 || !info[0].IsNumber() || !info[1].IsFunction() || info[0].As<Napi::Number>().Int64Value() <= 1) {
    Napi::Error::New(env, "Invalid application audio target").ThrowAsJavaScriptException(); return env.Null();
  }
  auto pid = info[0].As<Napi::Number>().Uint32Value();
  std::string error;
  auto status = capture.Initialize(pid, true, error);
  if (status != 0 || !error.empty()) {
    Napi::Error::New(env, error.empty() ? "Application audio unavailable" : error).ThrowAsJavaScriptException(); return env.Null();
  }
  callback = Napi::ThreadSafeFunction::New(env, info[1].As<Napi::Function>(), "ConcordiaAppAudio", 32, 1);
  capture.Start([](const uint8_t* bytes, size_t length, Capture::AudioMetadata meta) {
    if (!length || meta.sampleRate != 48000 || meta.channels != 2 || meta.bitsPerSample != 32 || !meta.isFloat) return;
    auto payload = new std::vector<uint8_t>(bytes, bytes + length);
    auto status = callback.NonBlockingCall(payload, [](Napi::Env env, Napi::Function fn, std::vector<uint8_t>* data) {
      if (env && !fn.IsEmpty()) fn.Call({Napi::Buffer<uint8_t>::Copy(env, data->data(), data->size())});
      delete data;
    });
    if (status != napi_ok) delete payload;
  });
  if (!capture.IsCapturing()) { callback.Abort(); Napi::Error::New(env, "Application audio could not start").ThrowAsJavaScriptException(); return env.Null(); }
  started = true;
  return Napi::Boolean::New(env, true);
}

Napi::Value Stop(const Napi::CallbackInfo& info) {
  if (started) { capture.Stop(); callback.Abort(); started = false; }
  return info.Env().Undefined();
}
Napi::Object Init(Napi::Env env, Napi::Object exports) {
  exports.Set("resolveWindow", Napi::Function::New(env, ResolveWindow));
  exports.Set("startCapture", Napi::Function::New(env, Start));
  exports.Set("stopCapture", Napi::Function::New(env, Stop));
  exports.Set("isCapturing", Napi::Function::New(env, [](const Napi::CallbackInfo& info) { return Napi::Boolean::New(info.Env(), capture.IsCapturing()); }));
  return exports;
}
NODE_API_MODULE(concordia_audio, Init)
