# Native application audio

Windows WASAPI and macOS ScreenCaptureKit implementations adapted from
https://github.com/CilginSinek/electron-native-screenshare at
69f9b317f08aad4a83b8c8843b019d230907667d (MIT; see LICENSE).

Concórdia uses include mode only, resolves the selected window's owner,
normalizes macOS samples to interleaved float32 stereo, and runs capture in
an isolated Electron utility process. There is no system-mix fallback.
Linux uses PulseAudio/PipeWire stream monitors in ../system-audio.js.
