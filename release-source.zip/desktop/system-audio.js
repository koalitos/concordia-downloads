const { spawn } = require('node:child_process')
const { linuxAudioSources } = require('./audio-sources')

// A autorização contém uma saída de aplicativo específica. Nunca há fallback
// para o monitor inteiro, microfone ou dispositivo padrão.
function createSystemAudio({ send, spawnProcess = spawn, listSources = linuxAudioSources, timeoutMs = 5000 }) {
  let allowed = null
  let child = null
  let session = 0
  let cancelPending = null

  function stop() {
    allowed = null
    session++
    cancelPending?.()
    cancelPending = null
    const previous = child
    child = null
    previous?.kill()
  }

  async function start() {
    const target = allowed
    if (!target || target.blocked || child) throw new Error('Selecione o som de um aplicativo antes de transmitir.')
    allowed = null
    const id = ++session
    const current = (await listSources()).find((source) => source.id === target.id && source.pid === target.pid && source.monitor === target.monitor && !source.blocked)
    if (id !== session) throw new Error('Captura de som cancelada.')
    if (!current) throw new Error('A saída de áudio escolhida foi encerrada. Selecione a fonte novamente.')
    return new Promise((resolve, reject) => {
      let ready = false
      let remainder = Buffer.alloc(0)
      const proc = spawnProcess('parec', [`--device=${current.monitor}`, `--monitor-stream=${current.index}`, '--raw', '--format=float32le', '--rate=48000', '--channels=2', '--latency-msec=40', '--process-time-msec=20', '--client-name=Concordia isolated audio'], { stdio: ['ignore', 'pipe', 'pipe'] })
      child = proc
      const fail = (message) => {
        if (session !== id) return
        clearTimeout(timer)
        if (!ready) reject(new Error(message))
        else send('system-audio:error', message)
        stop()
      }
      const timer = setTimeout(() => fail('O aplicativo selecionado não disponibilizou áudio.'), timeoutMs)
      cancelPending = () => { clearTimeout(timer); if (!ready) reject(new Error('Captura de som cancelada.')) }
      proc.stderr.on('data', () => {})
      proc.on('error', () => fail('Captura de som indisponível. Instale os utilitários do PulseAudio/PipeWire.'))
      proc.on('exit', () => fail('O som do aplicativo foi encerrado. Selecione a fonte novamente para retomar.'))
      proc.stdout.on('data', (chunk) => {
        if (session !== id) return
        const data = Buffer.concat([remainder, chunk])
        const length = data.length - data.length % 8 // frames estéreo float32
        remainder = Buffer.from(data.subarray(length))
        if (!length) return
        if (!ready) { ready = true; clearTimeout(timer); resolve({ sampleRate: 48000 }) }
        send('system-audio:data', new Uint8Array(data.subarray(0, length)))
      })
    })
  }

  return { allow(target) { stop(); allowed = target && !target.blocked ? target : null }, start, stop }
}
module.exports = { createSystemAudio }
