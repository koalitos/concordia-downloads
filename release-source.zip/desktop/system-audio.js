const { spawn } = require('node:child_process')

// PipeWire/PulseAudio: captura somente a saída (monitor), nunca microfone.
// O acesso é liberado pelo seletor de tela e consumido por uma única sessão.
function createSystemAudio({ send, spawnProcess = spawn, timeoutMs = 5000 }) {
  let allowed = false
  let child = null
  let session = 0
  let cancelPending = null

  function stop() {
    allowed = false
    session++
    cancelPending?.()
    cancelPending = null
    const previous = child
    child = null
    previous?.kill()
  }

  async function start() {
    if (!allowed || child) throw new Error('Selecione uma tela antes de capturar o som.')
    allowed = false
    const id = ++session
    return new Promise((resolve, reject) => {
      let ready = false
      let remainder = Buffer.alloc(0)
      const proc = spawnProcess('parec', ['--device=@DEFAULT_MONITOR@', '--raw', '--format=float32le', '--rate=48000', '--channels=2', '--latency-msec=40', '--process-time-msec=20'], { stdio: ['ignore', 'pipe', 'pipe'] })
      child = proc
      let detail = ''
      const fail = (message) => {
        if (session !== id) return
        clearTimeout(timer)
        if (!ready) reject(new Error(message))
        else send('system-audio:error', message)
        stop()
      }
      const timer = setTimeout(() => fail('Não foi possível iniciar o áudio da saída do sistema.'), timeoutMs)
      cancelPending = () => { clearTimeout(timer); if (!ready) reject(new Error('Captura de som cancelada.')) }
      proc.stderr.on('data', (chunk) => { detail = (detail + chunk.toString()).slice(-500) })
      proc.on('error', () => fail('Captura de som indisponível. O sistema precisa do comando parec (PulseAudio/PipeWire).'))
      proc.on('exit', () => fail(detail.trim() || 'A captura do som do sistema foi encerrada.'))
      proc.stdout.on('data', (chunk) => {
        if (session !== id) return
        const data = Buffer.concat([remainder, chunk])
        const length = data.length - data.length % 8 // frames estéreo float32
        remainder = Buffer.from(data.subarray(length))
        if (!length) return
        if (!ready) { ready = true; clearTimeout(timer); resolve({ sampleRate: 48000 }) }
        send('system-audio:data', new Uint8Array(data.subarray(0, length)))
      })
    })
  }

  return { allow() { allowed = true }, start, stop }
}
module.exports = { createSystemAudio }
