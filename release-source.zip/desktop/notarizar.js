const { notarize } = require('@electron/notarize')

// Notarização da Apple: depois de assinar com Developer ID, o app é enviado
// pra Apple, que verifica e devolve um "carimbo". Sem esse carimbo o
// Gatekeeper bloqueia mesmo um app assinado.
//
// Só roda quando as credenciais existem — sem elas o build segue no caminho
// ad-hoc, que abre com aviso mas abre.
exports.default = async function notarizar(context) {
  if (context.electronPlatformName !== 'darwin') return

  const { APPLE_ID, APPLE_APP_SPECIFIC_PASSWORD, APPLE_TEAM_ID } = process.env
  if (!APPLE_ID || !APPLE_APP_SPECIFIC_PASSWORD || !APPLE_TEAM_ID) {
    console.log('  • notarização pulada (sem credenciais da Apple)')
    return
  }

  const nome = context.packager.appInfo.productFilename
  console.log(`  • notarizando ${nome} — costuma levar de 2 a 15 minutos`)

  await notarize({
    appPath: `${context.appOutDir}/${nome}.app`,
    appleId: APPLE_ID,
    appleIdPassword: APPLE_APP_SPECIFIC_PASSWORD,
    teamId: APPLE_TEAM_ID,
  })

  console.log('  • notarizado')
}
